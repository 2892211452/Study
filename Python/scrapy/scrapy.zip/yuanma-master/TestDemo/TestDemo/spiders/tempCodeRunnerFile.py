import os
import numpy

# #关于分类的load函数
# def save(list, path, ):
#             numpy.save(path+".npy",list)
    
# def load(list, path):
#         a = numpy.load(path+".npy")
#         a = a.tolist()
#         list = []

#         for item in a:
#             list.append([item[0][0], item[1][0], item[2][0]])

#         print(a)
#         return(list)
# list=[]
# list =load(list, 'test')
# print(list)



# from scrapy import cmdline
# cmdline.execute("scrapy crawl paV -a url=http://www.imomoe.io/so.asp".split())

# count = 11
# print(count>10 and count<35)


# ans = 'http://www.imomoe.io/so.asp?page=1&fl=0&gj=热血'
# ans = ans.encode('gbk')
